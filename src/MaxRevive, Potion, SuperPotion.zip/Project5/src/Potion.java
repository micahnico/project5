
public class Potion extends Item {
	
	public Potion(String name, int price) {
		super(name, price);
	}
	
	@Override
	public void use(Pokemon p) {
		if(p.currentHealth < 90) {
			p.currentHealth += 10;
		}
		else if(p.currentHealth >= 90) {
			p.currentHealth = p.maxHealth;
		}
		else if(p.currentHealth == 0) {
			System.out.println("Sorry, Pokemon must be revived in order to use Potion.");
		}
	}
	

}
