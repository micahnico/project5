
public class SuperPotion extends Item{
	
	public SuperPotion(String name, int price) {
		super(name, price);
	}
	
	@Override
	public void use(Pokemon p) {
		if(p.currentHealth < 75) {
			p.currentHealth += 25;
		}
		else if(p.currentHealth >= 75) {
			p.currentHealth = p.maxHealth;
		}
		else if(p.currentHealth == 0) {
			System.out.println("Sorry, Pokemon must be revived in order to use Super Potion.");
		}
	}

}
